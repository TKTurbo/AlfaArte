<?php
include_once('app/templates/bovenstuk.php');
?>

<div class="container">
    <div class="page-header">
        <h1 class="text-white">Feedback</h1>
    </div>
</div>

<?php
include_once('app/templates/onderstuk.php');