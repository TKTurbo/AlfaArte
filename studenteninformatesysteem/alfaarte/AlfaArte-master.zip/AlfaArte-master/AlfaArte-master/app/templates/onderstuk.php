<footer class="page-footer font-small blue">

    <div class="footer-copyright text-center py-3">©<?= date("Y") ?> Copyright |
        <a class="mail_alfa" href="mailto:#">Alfa Arte</a>
    </div>

</footer>