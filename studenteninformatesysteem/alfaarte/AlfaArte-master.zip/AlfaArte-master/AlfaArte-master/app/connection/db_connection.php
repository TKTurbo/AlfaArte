<?php
$conn = new PDO(
        'mysql:host=localhost;dbname=alfa-arte',
        'root',
        ''
);