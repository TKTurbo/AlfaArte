<?php
include_once('app/templates/bovenstuk.php');
?>

<div class="container">
    <div class="page-header">
        <h1 class="text-white">Agenda</h1>
    </div>  

    <table class="table table-light">
        <thead>
        <tr>
            <th>Maandag</th>
            <th>Vak</th>
            <th>Docent</th>
        </tr>
        </thead>

        <tbody>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        </tbody>

    </table>

    <table class="table table-light">
        <thead>
        <tr>
            <th>Maandag</th>
            <th>Vak</th>
            <th>Docent</th>
        </tr>
        </thead>

        <tbody>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        </tbody>

    </table>

    <table class="table table-light">
        <thead>
        <tr>
            <th>Maandag</th>
            <th>Vak</th>
            <th>Docent</th>
        </tr>
        </thead>

        <tbody>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        </tbody>

    </table>

    <table class="table table-light">
        <thead>
        <tr>
            <th>Maandag</th>
            <th>Vak</th>
            <th>Docent</th>
        </tr>
        </thead>

        <tbody>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        </tbody>

    </table>

    <table class="table table-light margin-bottom-agenda">
        <thead>
        <tr>
            <th>Maandag</th>
            <th>Vak</th>
            <th>Docent</th>
        </tr>
        </thead>

        <tbody>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        <tr>
            <td>9:00 - 11:00</td>
            <td>Nederlands</td>
            <td>Mevr. Ruitenga</td>
        </tr>
        </tbody>

    </table>
</div>


<?php
include_once('app/templates/onderstuk.php');